import { Component } from '@angular/core';
import { Router } from '@angular/router';
// import {routingComponents} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

// startGame(){
//   this.router.navigate(['startGame']);
// }

// navToLeaderboards = function () {
//   this.router.navigateByUrl('/leaderboards');
// };



export class AppComponent {
  title = 'music-game-app';
}
